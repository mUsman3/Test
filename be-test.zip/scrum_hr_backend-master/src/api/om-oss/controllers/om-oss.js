'use strict';

/**
 * om-oss controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::om-oss.om-oss');
