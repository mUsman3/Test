'use strict';

/**
 * section-hero service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::section-hero.section-hero');
