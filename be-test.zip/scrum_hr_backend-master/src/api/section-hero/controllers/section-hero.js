'use strict';

/**
 * section-hero controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::section-hero.section-hero');
