'use strict';

/**
 * section-hero router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::section-hero.section-hero');
