'use strict';

/**
 * sustainability router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::sustainability.sustainability');
